package cloud.cnctr.cnctrcloud

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class CnctrcloudApplicationTests {

	@Test
	fun contextLoads() {
	}

}
